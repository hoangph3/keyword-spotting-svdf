#!/usr/bin/env python
# coding: utf-8

import os
import glob
import random
import IPython
import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from utils import *
from scipy.fftpack import fft
from scipy import signal
from scipy.io import wavfile
from pydub import AudioSegment
from python_speech_features import logfbank

# filename = './data/raw_data/backgrounds/white_noise.wav'
# sample_rate, signal = wavfile.read(filename)
# logfbank_feat = logfbank(signal, sample_rate, winlen = 0.03, winstep = 0.01,  nfilt = 40).astype(np.int16)
# print(signal.shape)
# print(logfbank_feat.shape)

sample_rate = 16000
Tx = Ty = 298
n_freq = 40


# Calib amplitude
def match_target_amplitude(sound, target_dBFS):
    change_in_dBFS = target_dBFS - sound.dBFS
    return sound.apply_gain(change_in_dBFS)

# Labeling
def insert_ones(y, segment_end_ms):
    segment_end_y = int(segment_end_ms * Ty / 3000)
    for i in range(segment_end_y + 1, segment_end_y + 50 + 1):
        if i < Ty:
            y[i, 0] = 1
    return y

# Array train data
x_train = []
y_train = []

# Load raw audio files for speech synthesis
def load_raw_audio(name_activates, name_negatives):
    activates = []
    backgrounds = []
    negatives = []
    for filename in os.listdir("./data/raw_data/" + name_activates):
        if filename.endswith("wav"):
            activate = AudioSegment.from_wav("./data/raw_data/" + name_activates + filename)
            activates.append(activate)
    for filename in os.listdir("./data/raw_data/backgrounds/"):
        if filename.endswith("wav"):
            background = AudioSegment.from_wav("./data/raw_data/backgrounds/" + filename)
            backgrounds.append(background)
    for filename in os.listdir("./data/raw_data/" + name_negatives):
        if filename.endswith("wav"):
            negative = AudioSegment.from_wav("./data/raw_data/" + name_negatives + filename)
            negatives.append(negative)
    return activates, negatives, backgrounds


with open('data_config.py') as f:
    name_folder = f.read().splitlines()

for j in range(len(name_folder)):
    name_folder[j] = name_folder[j] + '/'
    activates, negatives, backgrounds = load_raw_audio("marvin/train/", name_folder[j])
    for i in range(len(activates)):
        if(i%2 == 0):
            background = backgrounds[random.randint(0, len(backgrounds)-1)]
            epsilon = random.randint(10, 15)
            background = background - epsilon
            
            position = np.random.randint(0, 25)
            y = np.zeros((Ty, 1))
            
            segment_ms = len(activates[i])
            background = background.overlay(activates[i], position = position)
            position += segment_ms - 1
            y = insert_ones(y, position)

            position = position + np.random.randint(0,25)
            
            segment_ms = len(negatives[i])
            background = background.overlay(negatives[i], position = position)
            position += segment_ms - 1

            background = match_target_amplitude(background, - epsilon)
            file_handle = background.export("./data/raw_data/tmp/train/train"  + str(i) +".wav", format="wav")
            _, signal = wavfile.read("./data/raw_data/tmp/train/train"  + str(i) +".wav")
            
            #x = logfbank(signal, sample_rate, winlen = 0.03, winstep = 0.01,  nfilt = 40).astype(np.float32)
            x_train.append(signal)
            y_train.append(y)
        else:
            background = backgrounds[random.randint(0, len(backgrounds)-1)]
            epsilon = random.randint(10, 15)
            background = background - epsilon
            
            position = np.random.randint(0, 25)
            y = np.zeros((Ty, 1))
            
            segment_ms = len(negatives[i])
            background = background.overlay(negatives[i], position = position)
            position += segment_ms - 1

            position = position + np.random.randint(0,25)

            segment_ms = len(activates[i])
            background = background.overlay(activates[i], position = position)
            position += segment_ms - 1
            y = insert_ones(y, position)

            background = match_target_amplitude(background, - epsilon)
            file_handle = background.export("./data/raw_data/tmp/train/train"  + str(i) +".wav", format="wav")
            _, signal = wavfile.read("./data/raw_data/tmp/train/train"  + str(i) +".wav")
            
            #x = logfbank(signal, sample_rate, winlen = 0.03, winstep = 0.01,  nfilt = 40).astype(np.float32)
            x_train.append(signal)
            y_train.append(y)

# Convert list to array and save .npy
x_train = np.asarray(x_train)
y_train = np.asarray(y_train)
# Save and check shape 
np.save("./data/x_train.npy", x_train)
np.save("./data/y_train.npy", y_train)

# fig = plt.figure(figsize=(14, 8))
# ax1 = fig.add_subplot(211)
# ax1.set_xlabel('Ty')
# k = 589
# ax1.plot(y_train[k,:, :])
# for i in range(198 - 1):
#     if y_train[k,i,0] == 0 and y_train[k, i+1, 0] == 1:
#         print(i)


# Array test data
x_test = []
y_test = []

with open('data_config.py') as f:
    name_folder = f.read().splitlines()

for j in range(len(name_folder)):
    name_folder[j] = name_folder[j] + '/'
    activates, negatives, backgrounds = load_raw_audio("marvin/test/", name_folder[j])
    for i in range(len(activates)):
        if(i%2 == 0):
            background = backgrounds[random.randint(0, len(backgrounds)-1)]
            epsilon = random.randint(10, 15)
            background = background - epsilon
            
            position = np.random.randint(0, 25)
            y = np.zeros((Ty, 1))

            segment_ms = len(negatives[i])
            background = background.overlay(negatives[i], position = position)
            position += segment_ms - 1

            position = position + np.random.randint(0,25)

            segment_ms = len(activates[i])
            background = background.overlay(activates[i], position = position)
            position += segment_ms - 1
            y = insert_ones(y, position)

            background = match_target_amplitude(background, - epsilon)
            file_handle = background.export("./data/raw_data/tmp/test/test"  + str(i) +".wav", format="wav")
            _, signal = wavfile.read("./data/raw_data/tmp/test/test"  + str(i) +".wav")
            
            #x = logfbank(signal, sample_rate, winlen = 0.03, winstep = 0.01,  nfilt = 40).astype(np.float32)
            x_test.append(signal)
            y_test.append(y)
        else:
            background = backgrounds[random.randint(0, len(backgrounds)-1)]
            epsilon = random.randint(10, 15)
            background = background - epsilon
            
            position = np.random.randint(0, 25)
            y = np.zeros((Ty, 1))
            
            segment_ms = len(activates[i])
            background = background.overlay(activates[i], position = position)
            position += segment_ms - 1
            y = insert_ones(y, position)

            position = position + np.random.randint(0,25)
            
            segment_ms = len(negatives[i])
            background = background.overlay(negatives[i], position = position)
            position += segment_ms - 1

            background = match_target_amplitude(background, - epsilon)
            file_handle = background.export("./data/raw_data/tmp/test/test"  + str(i) +".wav", format="wav")
            _, signal = wavfile.read("./data/raw_data/tmp/test/test"  + str(i) +".wav")
            
            #x = logfbank(signal, sample_rate, winlen = 0.03, winstep = 0.01,  nfilt = 40).astype(np.float32)
            x_test.append(signal)
            y_test.append(y)

# Convert list to array and save .npy
x_test = np.asarray(x_test)
y_test = np.asarray(y_test)
# Save and check shape 
np.save("./data/x_test.npy", x_test)
np.save("./data/y_test.npy", y_test)

print("Data shape:")
print("Train feature = ", x_train.shape)
print("Train label = ", y_train.shape)
print("Test feature = ", x_test.shape)
print("Test label = ", y_test.shape)