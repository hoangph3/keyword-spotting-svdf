import numpy as np
import os
from pydub import AudioSegment
from scipy.io import wavfile
import matplotlib.pyplot as plt
from utils import *

def preprocess_audio(filename):
    padding = AudioSegment.silent(duration=3000)
    segment = AudioSegment.from_wav(filename)[:3000]
    segment = padding.overlay(segment)
    segment = segment.set_frame_rate(16000)
    segment.export(filename, format='wav')
   
k = int(input("k = "))
file_audio = './data/test' + str(k) + '.wav'
preprocess_audio(file_audio)

_, signal = wavfile.read(file_audio)

model=keyword_marvin_v3(input_shape = (48000,), dropout = 0.0)
weights_name = 'best_weights'
model.load_weights(os.path.join('training/keyword_marvin_v3/', weights_name))

output = model.predict(signal.reshape(1,-1))

print(output.shape)
output = np.squeeze(output)
print(output.shape)
print("Output: \n", output)
plt.plot(output)
plt.show()

