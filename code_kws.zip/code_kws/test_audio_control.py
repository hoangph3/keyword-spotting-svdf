import numpy as np
import os
from pydub import AudioSegment
from scipy.io import wavfile
import matplotlib.pyplot as plt
from utils import *
from DataSettings import DataSettings
from TrainingSettings import TrainingSettings
import input_data

def preprocess_audio(filename):
    padding = AudioSegment.silent(duration=1000)
    segment = AudioSegment.from_wav(filename)[:1000]
    segment = padding.overlay(segment)
    segment = segment.set_frame_rate(16000)
    segment.export(filename, format='wav')
   
k = int(input("k = "))
file_audio = 'test' + str(k) + '.wav'
preprocess_audio(file_audio)

_, signal = wavfile.read(file_audio)

data_settings = DataSettings(
    window_size_ms = 40.0,
    window_stride_ms = 20.0,
    dct_num_features = 40,
    mel_num_bins = 80,
    mel_upper_edge_hertz = 7000,
    silence_percentage = 6.0,
    unknown_percentage = 6.0,
    wanted_words = 'on,off,up,down,zero,one,two,three,four,five,six,seven,eight,nine')

training_settings = TrainingSettings()
time_shift_samples = int((data_settings.time_shift_ms * data_settings.sample_rate) / 1000)
audio_processor = input_data.AudioProcessor(data_settings)

with open(os.path.join('training/E2E_1stage_v8/', 'labels.txt'), 'r') as fd:
    labels_txt = fd.read()

labels = labels_txt.split()

model = E2E_1stage_v8(input_shape=(16000), data_settings=data_settings)

weights_name = 'best_weights'
model.load_weights(os.path.join('training/E2E_1stage_v8/', weights_name))

output = model.predict(signal.reshape(1,-1))

print(output.shape)
print("Output: \n ", output)

output_argmax = np.argmax(output)
print("Predict word: ", labels[output_argmax])


plt.plot(output[0])
plt.show()